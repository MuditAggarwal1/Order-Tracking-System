module.exports = {
        dbcon: 'mongodb://localhost/cmscart'
}